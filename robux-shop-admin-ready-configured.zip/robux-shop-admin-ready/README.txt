SHOPROBUXGMHUB - ADMIN READY

1) Chạy schema.sql trong Supabase SQL Editor (nếu chưa chạy).
2) Đảm bảo UID admin đã có trong public.admin_users.
3) Đưa toàn bộ thư mục lên hosting/static site.
4) Mở admin.html.
5) admin.html đã được cấu hình sẵn Project URL và Publishable key cho project ShopROBUXGMHUB.
6) Mở admin.html và đăng nhập bằng email/mật khẩu Supabase của tài khoản đã cấp quyền admin.
7) KHÔNG dùng Service Role Key trong trình duyệt.

Admin có: thống kê đơn, tìm kiếm, đổi trạng thái, tải lại, đăng xuất.
