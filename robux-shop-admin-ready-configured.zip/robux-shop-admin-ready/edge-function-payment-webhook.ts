// Supabase Edge Function — PAYMENT WEBHOOK SKELETON
// Deploy as: supabase functions deploy payment-webhook
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method Not Allowed", {status:405});

  const body = await req.text();
  const secret = Deno.env.get("PAYMENT_WEBHOOK_SECRET") ?? "";
  const supplied = req.headers.get("x-webhook-secret") ?? "";

  // Replace this with the payment provider's official signature verification.
  if (!secret || supplied !== secret)
    return new Response("Unauthorized", {status:401});

  let event;
  try { event = JSON.parse(body); }
  catch { return new Response("Bad JSON",{status:400}); }

  // Expected example:
  // { order_code:"RBX-...", payment_reference:"...", paid:true }
  if (!event.order_code || event.paid !== true)
    return new Response("Ignored",{status:200});

  const db = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const { error } = await db.from("orders")
    .update({
      status:"paid",
      payment_reference:event.payment_reference ?? null,
      paid_at:new Date().toISOString()
    })
    .eq("order_code",event.order_code)
    .eq("status","pending_payment");

  if (error) return new Response("Database error",{status:500});
  return new Response("OK",{status:200});
});
